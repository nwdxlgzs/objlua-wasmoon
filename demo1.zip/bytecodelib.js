
// Constants
const LUA_TNIL = 0;
const LUA_TBOOLEAN = 1;
const LUA_TLIGHTUSERDATA = 2;
const LUA_TNUMBER = 3;
const LUA_TSTRING = 4;
const LUA_TTABLE = 5;
const LUA_TFUNCTION = 6;
const LUA_TUSERDATA = 7;
const LUA_TTHREAD = 8;
const LUAI_MAXSHORTLEN = 40;

let makevariant = function (t, v) { return t | (v << 4); }

const LUA_VSHRSTR = makevariant(LUA_TSTRING, 0);
const LUA_VLNGSTR = makevariant(LUA_TSTRING, 1);
const LUA_VNUMINT = makevariant(LUA_TNUMBER, 0);
const LUA_VNUMFLT = makevariant(LUA_TNUMBER, 1);
const LUA_VNIL = makevariant(LUA_TNIL, 0);
const LUA_VFALSE = makevariant(LUA_TBOOLEAN, 0);
const LUA_VTRUE = makevariant(LUA_TBOOLEAN, 1);

let ttypetag = function (o) { return o.tt_ & 0x3F; }

const opmodes = [
    "iABC", "iAsBx", "iAsBx", "iABx", "iABx", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "isJ", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC", "iABC", "iABx", "iABx", "iABx", "iABC", "iABx", "iABC", "iABx",
    "iABC", "iABC", "iAx", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC", "iABC",
    "iABC", "iABC",
];

const opnames = [
    "MOVE", "LOADI", "LOADF", "LOADK", "LOADKX",
    "LOADFALSE", "LFALSESKIP", "LOADTRUE", "LOADNIL", "GETUPVAL",
    "SETUPVAL", "GETTABUP", "GETTABLE", "GETI", "GETFIELD",
    "SETTABUP", "SETTABLE", "SETI", "SETFIELD", "NEWTABLE",
    "SELF", "ADDI", "ADDK", "SUBK", "MULK",
    "MODK", "POWK", "DIVK", "IDIVK", "BANDK",
    "BORK", "BXORK", "SHRI", "SHLI", "ADD",
    "SUB", "MUL", "MOD", "POW", "DIV",
    "IDIV", "BAND", "BOR", "BXOR", "SHL",
    "SHR", "MMBIN", "MMBINI", "MMBINK", "UNM",
    "BNOT", "NOT", "LEN", "CONCAT", "CLOSE",
    "TBC", "JMP", "EQ", "LT", "LE",
    "EQK", "EQI", "LTI", "LEI", "GTI",
    "GEI", "TEST", "TESTSET", "CALL", "TAILCALL",
    "RETURN", "RETURN0", "RETURN1", "FORLOOP", "FORPREP",
    "TFORPREP", "TFORCALL", "TFORLOOP", "SETLIST", "CLOSURE",
    "VARARG", "VARARGPREP", "EXTRAARG", "DEFCLASS", "DEFFIELD",
    "METHODINIT", "DEFMETHODARGTYPE", "DEFMETHOD", "CKMCONST", "CKCABSTRACT",
    "TYPEOF", "INSTANCEOF",
];

class Instruction {
    constructor(instruction) {
        this.instruction = instruction;
    }

    static parse(instruction) {
        const op = (instruction >> Instruction.POS_OP) & Instruction.MASK1(Instruction.SIZE_OP, 0);
        const opmode = opmodes[op];
        if (opmode === "iABC") {
            return new iABC(instruction);
        } else if (opmode === "iABx") {
            return new iABx(instruction);
        } else if (opmode === "iAsBx") {
            return new iAsBx(instruction);
        } else if (opmode === "iAx") {
            return new iAx(instruction);
        } else if (opmode === "isJ") {
            return new isJ(instruction);
        }
        return new Instruction(instruction);
    }

    getOpName() {
        const opname = opnames[this.getOpCode()];
        if (opname === undefined) return "UNKNOWN";
        return opname;
    }

    toString() {
        return `<${this.getOpName()}\t${this.instruction}>`;
    }

    static SIZE_C = 8;
    static SIZE_B = 8;
    static SIZE_Bx = (Instruction.SIZE_C + Instruction.SIZE_B + 1);
    static SIZE_A = 8;
    static SIZE_Ax = (Instruction.SIZE_Bx + 8);
    static SIZE_sJ = (Instruction.SIZE_Bx + 8);
    static SIZE_OP = 7;
    static POS_OP = 0;
    static POS_A = (Instruction.POS_OP + 7);
    static POS_k = (Instruction.POS_A + 8);
    static POS_B = (Instruction.POS_k + 1);
    static POS_C = (Instruction.POS_B + 8);
    static POS_Bx = (Instruction.POS_A + 8);
    static POS_Ax = (Instruction.POS_A);
    static POS_sJ = (Instruction.POS_A);
    static MAXARG_Bx = ((1 << Instruction.SIZE_Bx) - 1);
    static OFFSET_sBx = (Instruction.MAXARG_Bx >> 1);
    static MAXARG_Ax = ((1 << Instruction.SIZE_Ax) - 1);
    static MAXARG_sJ = ((1 << Instruction.SIZE_sJ) - 1);
    static OFFSET_sJ = (Instruction.MAXARG_sJ >> 1);
    static MAXARG_A = ((1 << Instruction.SIZE_A) - 1);
    static MAXARG_B = ((1 << Instruction.SIZE_B) - 1);
    static MAXARG_C = ((1 << Instruction.SIZE_C) - 1);
    static OFFSET_sC = (Instruction.MAXARG_C >> 1);

    static int2sC(i) { return i + Instruction.OFFSET_sC; }
    static sC2int(i) { return i - Instruction.OFFSET_sC; }
    static MASK1(n, p) { return ((~((~0) << n)) << p); }
    static MASK0(n, p) { return ~Instruction.MASK1(n, p); }

    getOpCode() { return (this.instruction >> Instruction.POS_OP) & Instruction.MASK1(Instruction.SIZE_OP, 0); }

    setOpCode(o) {
        this.instruction = (this.instruction & Instruction.MASK0(Instruction.SIZE_OP, Instruction.POS_OP)) |
            ((o << Instruction.POS_OP) & Instruction.MASK1(Instruction.SIZE_OP, Instruction.POS_OP));
    }

    getarg(pos, size) { return (this.instruction >> pos) & Instruction.MASK1(size, 0); }

    setarg(v, pos, size) {
        this.instruction = (this.instruction & Instruction.MASK0(size, pos)) | ((v << pos) & Instruction.MASK1(size, pos));
    }
}

class iABC extends Instruction {
    toString() {
        return `<iABC|${this.getOpName()}\tA=${this.getA()}\tB=${this.getB()}\tC=${this.getC()}\tK=${this.getK()}>`;
    }

    getA() { return this.getarg(Instruction.POS_A, Instruction.SIZE_A); }
    setA(v) { this.setarg(v, Instruction.POS_A, Instruction.SIZE_A); }
    getB() { return this.getarg(Instruction.POS_B, Instruction.SIZE_B); }
    getsB() { return Instruction.sC2int(this.getB()); }
    setB(v) { this.setarg(v, Instruction.POS_B, Instruction.SIZE_B); }
    getC() { return this.getarg(Instruction.POS_C, Instruction.SIZE_C); }
    getsC() { return Instruction.sC2int(this.getC()); }
    setC(v) { this.setarg(v, Instruction.POS_C, Instruction.SIZE_C); }
    getK() { return this.getarg(Instruction.POS_k, 1); }
    setK(v) { this.setarg(v, Instruction.POS_k, 1); }
}

class iABx extends Instruction {
    toString() {
        return `<iABx|${this.getOpName()}\tA=${this.getA()}\tBx=${this.getBx()}>`;
    }

    getA() { return this.getarg(Instruction.POS_A, Instruction.SIZE_A); }
    setA(v) { this.setarg(v, Instruction.POS_A, Instruction.SIZE_A); }
    getBx() { return this.getarg(Instruction.POS_Bx, Instruction.SIZE_Bx); }
    setBx(v) { this.setarg(v, Instruction.POS_Bx, Instruction.SIZE_Bx); }
}

class iAsBx extends Instruction {
    toString() {
        return `<iAsBx|${this.getOpName()}\tA=${this.getA()}\tsBx=${this.getsBx()}>`;
    }

    getA() { return this.getarg(Instruction.POS_A, Instruction.SIZE_A); }
    setA(v) { this.setarg(v, Instruction.POS_A, Instruction.SIZE_A); }
    setBx(v) { this.setarg(v, Instruction.POS_Bx, Instruction.SIZE_Bx); }
    getsBx() { return this.getarg(Instruction.POS_Bx, Instruction.SIZE_Bx) - Instruction.OFFSET_sBx; }
    setsBx(v) { this.setBx(v + Instruction.OFFSET_sBx); }
}

class iAx extends Instruction {
    toString() {
        return `<iAx|${this.getOpName()}\tAx=${this.getAx()}>`;
    }

    getAx() { return this.getarg(Instruction.POS_Ax, Instruction.SIZE_Ax); }
    setAx(v) { this.setarg(v, Instruction.POS_Ax, Instruction.SIZE_Ax); }
}

class isJ extends Instruction {
    toString() {
        return `<isJ|${this.getOpName()}\tsJ=${this.getsJ()}>`;
    }

    getsJ() { return this.getarg(Instruction.POS_sJ, Instruction.SIZE_sJ) - Instruction.OFFSET_sJ; }
    setsJ(v) { this.setarg(v + Instruction.OFFSET_sJ, Instruction.POS_sJ, Instruction.SIZE_sJ); }
}

class TValue {
    constructor(value_, tt_) {
        this.value_ = value_;
        this.tt_ = tt_;
    }

    static tsvalue(o) { return o.value_; }
    static ivalue(o) { return o.value_; }
    static fltvalue(o) { return o.value_; }

    get() {
        const tag = ttypetag(this);
        if (tag === LUA_VNIL) {
            return null;
        } else if (tag === LUA_VFALSE) {
            return false;
        } else if (tag === LUA_VTRUE) {
            return true;
        } else if (tag === LUA_VNUMINT) {
            return TValue.ivalue(this);
        } else if (tag === LUA_VNUMFLT) {
            return TValue.fltvalue(this);
        } else if (tag === LUA_VSHRSTR || tag === LUA_VLNGSTR) {
            return TValue.tsvalue(this);
        } else {
            return null;
        }
    }

    static fromString(value) {
        const len = value.length;
        let tt_;
        if (len < LUAI_MAXSHORTLEN) {
            tt_ = LUA_VSHRSTR;
        } else {
            tt_ = LUA_VLNGSTR;
        }
        return new TValue(value, tt_);
    }

    static fromNumber(value) {
        let tt_;
        if (Math.floor(value) === value) {
            tt_ = LUA_VNUMINT;
        } else {
            tt_ = LUA_VNUMFLT;
        }
        return new TValue(value, tt_);
    }

    static fromBoolean(value) {
        let tt_;
        if (value) {
            tt_ = LUA_VTRUE;
        } else {
            tt_ = LUA_VFALSE;
        }
        return new TValue(value, tt_);
    }

    static fromNil() {
        return new TValue(null, LUA_VNIL);
    }

    toString() {
        return `<TValue\tt_=${this.tt_}\tvalue=${this.get()}>`;
    }
}

class Upvaldesc {
    constructor(name, instack, idx, kind) {
        this.name = name;
        this.instack = instack;
        this.idx = idx;
        this.kind = kind;
    }

    toString() {
        const name = this.name || "<none>";
        return `<Upvaldesc\tname=${name}\tinstack=${this.instack}\tidx=${this.idx}\tkind=${this.kind}>`;
    }
}

class LocVar {
    constructor(varname, startpc, endpc) {
        this.varname = varname;
        this.startpc = startpc;
        this.endpc = endpc;
    }

    toString() {
        const varname = this.varname || "<none>";
        return `<LocVar\tvarname=${varname}\tstartpc=${this.startpc}\tendpc=${this.endpc}>`;
    }
}

class AbsLineInfo {
    constructor(pc, line) {
        this.pc = pc;
        this.line = line;
    }

    toString() {
        return `<AbsLineInfo\tpc=${this.pc}\tline=${this.line}>`;
    }
}

class Proto {
    constructor() {
        this.k = [];
        this.code = [];
        this.p = [];
        this.upvalues = [];
        this.lineinfo = [];
        this.abslineinfo = [];
        this.locvars = [];
        this.numparams = 0;
        this.is_vararg = false;
        this.maxstacksize = 0;
        this.sizeupvalues = 0;
        this.sizek = 0;
        this.sizecode = 0;
        this.sizelineinfo = 0;
        this.sizep = 0;
        this.sizelocvars = 0;
        this.sizeabslineinfo = 0;
        this.linedefined = 0;
        this.lastlinedefined = 0;
        this.source = null;
        this.nupvalues = 0;
    }

    toString() {
        const buffer = [];
        buffer.push(`<Proto\n\tnumparams=${this.numparams}\n\tis_vararg=${this.is_vararg}\n\tmaxstacksize=${this.maxstacksize}\n\tsizeupvalues=${this.sizeupvalues}\n\t` +
            `sizek=${this.sizek}\n\tsizecode=${this.sizecode}\n\tsizelineinfo=${this.sizelineinfo}\n\tsizep=${this.sizep}\n\tsizelocvars=${this.sizelocvars}\n\tsizeabslineinfo=${this.sizeabslineinfo}\n\t` +
            `linedefined=${this.linedefined}\n\tlastlinedefined=${this.lastlinedefined}\n\tnupvalues=${this.nupvalues}\n\tk={\n`);

        for (let i = 0; i < this.sizek; i++) {
            buffer.push(`\t\t[${i}]=${this.k[i]},\n`);
        }

        buffer.push("\t},\n\tcode={\n");
        for (let i = 0; i < this.sizecode; i++) {
            buffer.push(`\t\t[${i}]=${this.code[i]},\n`);
        }

        buffer.push("\t},\n\tupvalues={\n");
        for (let i = 0; i < this.sizeupvalues; i++) {
            buffer.push(`\t\t[${i}]=${this.upvalues[i]},\n`);
        }

        buffer.push("\t},\n\tlineinfo={\n");
        for (let i = 0; i < this.sizelineinfo; i++) {
            buffer.push(`\t\t[${i}]=${this.lineinfo[i]},\n`);
        }

        buffer.push("\t},\n\tabslineinfo={\n");
        for (let i = 0; i < this.sizeabslineinfo; i++) {
            buffer.push(`\t\t[${i}]=${this.abslineinfo[i]},\n`);
        }

        buffer.push("\t},\n\tlocvars={\n");
        for (let i = 0; i < this.sizelocvars; i++) {
            buffer.push(`\t\t[${i}]=${this.locvars[i]},\n`);
        }

        buffer.push("\t},\n\tsource=");
        if (this.source) {
            buffer.push(this.source);
        } else {
            buffer.push("<null>");
        }
        buffer.push("\n>");
        return buffer.join("");
    }
}

class lundump {
    static LUA_SIGNATURE = "\x1bLua";
    static LUAC_DATA = "\x19\x93\r\n\x1a\n";
    static LUAC_VERSION = 0x54;
    static LUAC_FORMAT = 0;
    static sizeof_Instruction = 4;
    static sizeof_lua_Integer = 8;
    static sizeof_lua_Number = 8;
    static MAX_SIZET = 9223372036854775807n;
    static INT_MAX = 0x7fffffff;
    static LUAC_INT = 0x5678;
    static LUAC_NUM = 370.5;

    constructor(bytes) {
        this.bytes = bytes;
        this.pos = 0;
        this.len = bytes.length;
    }

    load() {
        console.log(`parse start, total bytes ${this.len}`);
        this.pos = 0;
        this.checkHeader();
        const proto = new Proto();
        proto.nupvalues = this.loadByte();
        this.loadFunction(proto, null);
        console.log(`parse end, read ${this.pos} bytes`);
        return proto;
    }

    loadFunction(f, psource) {
        f.source = this.loadStringN();
        if (f.source === null) {
            f.source = psource;
        }
        f.linedefined = this.loadInt();
        f.lastlinedefined = this.loadInt();
        f.numparams = this.loadByte();
        f.is_vararg = this.loadByte() !== 0;
        f.maxstacksize = this.loadByte();
        this.loadCode(f);
        this.loadConstants(f);
        this.loadUpvalues(f);
        this.loadProtos(f);
        this.loadDebug(f);
    }

    loadProtos(f) {
        const n = this.loadInt();
        f.sizep = n;
        for (let i = 0; i < n; i++) {
            const p = new Proto();
            this.loadFunction(p, f.source);
            f.p[i] = p;
        }
    }

    loadDebug(f) {
        let n = this.loadInt();
        f.sizelineinfo = n;
        for (let i = 0; i < n; i++) {
            f.lineinfo[i] = this.loadByte();
        }

        n = this.loadInt();
        f.sizeabslineinfo = n;
        for (let i = 0; i < n; i++) {
            const pc = this.loadInt();
            const line = this.loadInt();
            f.abslineinfo[i] = new AbsLineInfo(pc, line);
        }

        n = this.loadInt();
        f.sizelocvars = n;
        for (let i = 0; i < n; i++) {
            const varname = this.loadStringN();
            const startpc = this.loadInt();
            const endpc = this.loadInt();
            f.locvars[i] = new LocVar(varname, startpc, endpc);
        }

        n = this.loadInt();
        if (n !== 0) {
            n = f.sizeupvalues;
        }
        for (let i = 0; i < n; i++) {
            f.upvalues[i].name = this.loadStringN();
        }
    }

    loadUpvalues(f) {
        const n = this.loadInt();
        f.sizeupvalues = n;
        for (let i = 0; i < n; i++) {
            const instack = this.loadByte() !== 0;
            const idx = this.loadByte();
            const kind = this.loadByte();
            f.upvalues[i] = new Upvaldesc(null, instack, idx, kind);
        }
    }

    loadConstants(f) {
        const n = this.loadInt();
        f.sizek = n;
        for (let i = 0; i < n; i++) {
            const t = this.loadByte();
            let o;
            if (t === LUA_VNIL) {
                o = TValue.fromNil();
            } else if (t === LUA_VFALSE) {
                o = TValue.fromBoolean(false);
            } else if (t === LUA_VTRUE) {
                o = TValue.fromBoolean(true);
            } else if (t === LUA_VNUMFLT) {
                o = TValue.fromNumber(this.loadNumber());
            } else if (t === LUA_VNUMINT) {
                o = TValue.fromNumber(this.loadInteger());
            } else if (t === LUA_VSHRSTR || t === LUA_VLNGSTR) {
                o = TValue.fromString(this.loadString());
            } else {
                o = TValue.fromNil();
            }
            f.k[i] = o;
        }
    }

    loadString() {
        const st = this.loadStringN();
        if (st === null) {
            throw new Error("bad format for constant string");
        }
        return st;
    }

    loadCode(f) {
        const n = this.loadInt();
        f.sizecode = n;
        const isLittleEndian = lundump.LUAC_FORMAT === 0;

        for (let i = 0; i < n; i++) {
            const str = this.loadVector(lundump.sizeof_Instruction);
            const view = new DataView(new Uint8Array(str).buffer);
            const inst = view.getInt32(0, isLittleEndian);
            f.code[i] = Instruction.parse(inst);
        }
    }

    loadStringN() {
        const size = this.loadSize();
        if (size === 0) return null;
        const str = this.loadVector(size - 1, false);
        return str;
    }

    loadSize() {
        return this.loadUnsigned(lundump.MAX_SIZET);
    }

    loadInt() {
        return this.loadUnsigned(lundump.INT_MAX);
    }

    loadUnsigned(limit) {
        let x = 0n;
        let b;
        limit = BigInt(limit) >> 7n;
        do {
            b = this.loadByte();
            if (x >= limit) {
                throw new Error("integer overflow");
            }
            x = (x << 7n) | (BigInt(b) & 0x7fn);
        } while ((b & 0x80) === 0);
        return Number(x);//应该不会真勇那么大吧？转回Number用了
    }

    checkHeader() {
        this.checkliteral(lundump.LUA_SIGNATURE, "not a binary chunk");
        if (this.loadByte() !== lundump.LUAC_VERSION) {
            throw new Error("version mismatch");
        }
        if (this.loadByte() !== lundump.LUAC_FORMAT) {
            throw new Error("format mismatch");
        }
        this.checkliteral(lundump.LUAC_DATA, "corrupted chunk");
        this.checksize(lundump.sizeof_Instruction, "Instruction");
        this.checksize(lundump.sizeof_lua_Integer, "lua_Integer");
        this.checksize(lundump.sizeof_lua_Number, "lua_Number");
        if (this.loadInteger() != lundump.LUAC_INT) {//bigint vs int
            throw new Error("integer format mismatch");
        }
        if (this.loadNumber() !== lundump.LUAC_NUM) {
            throw new Error("float format mismatch");
        }
    }

    loadInteger() {
        const str = this.loadVector(lundump.sizeof_lua_Integer);
        const isLittleEndian = lundump.LUAC_FORMAT === 0;
        const view = new DataView(new Uint8Array(str).buffer);
        if (lundump.sizeof_lua_Integer === 4) {
            return view.getInt32(0, isLittleEndian); // 32-bit integer
        } else if (lundump.sizeof_lua_Integer === 8) {
            return view.getBigInt64(0, isLittleEndian); // 64-bit integer (BigInt)
        } else {
            throw new Error("Unsupported integer size");
        }
    }

    loadNumber() {
        const str = this.loadVector(lundump.sizeof_lua_Number);
        const isLittleEndian = lundump.LUAC_FORMAT === 0;
        const view = new DataView(new Uint8Array(str).buffer);
        return view.getFloat64(0, isLittleEndian);
    }

    checksize(size, tname) {
        const gotsize = this.loadByte();
        if (gotsize !== size) {
            throw new Error(`${tname} size mismatch`);
        }
    }

    loadVector(size, wrap = true) {
        const adjust_size = Math.max(size, 1);
        if (this.pos + adjust_size > this.len) {
            throw new Error("unexpected end of data");
        }
        const result = this.bytes.slice(this.pos, this.pos + size);
        this.pos += adjust_size;
        if (wrap) {
            const arr = new Uint8Array(adjust_size);
            for (let i = 0; i < adjust_size; i++) {
                arr[i] = result.charCodeAt(i) & 0xFF; // 确保是 0-255
            }
            return arr;
        } else return result;
    }

    loadByte() {
        if (this.pos >= this.len) {
            throw new Error("unexpected end of data");
        }
        return this.bytes[this.pos++].charCodeAt(0);
    }

    checkliteral(checkstr, errmsg) {
        const gotliteral = this.loadVector(checkstr.length, false);
        if (gotliteral.toString() !== checkstr) {
            throw new Error(errmsg);
        }
    }
}

class ldump {
    static DIBS = Math.ceil((8 * 8 + 6) / 7); // sizeof_size_t = 8, CHAR_BIT = 8

    constructor(f, strip = false) {
        this.f = f;
        this.strip = strip;
        this.buffer = [];
    }

    dump() {
        console.log("dumping bytecode...");
        this.buffer = [];
        this.dumpHeader();
        this.dumpByte(this.f.nupvalues);
        this.dumpFunction(this.f, null);
        const bytecode = ''.concat(...this.buffer);
        console.log(`dumping bytecode... done! size = ${bytecode.length} with ${this.buffer.length} elements.`);
        return bytecode;
    }

    dumpSize(x) {
        const buff = new Array(ldump.DIBS).fill(0);
        let n = 0;
        do {
            n++;
            buff[ldump.DIBS - n] = x & 0x7f;
            x = x >> 7;
        } while (x !== 0);
        buff[ldump.DIBS - 1] = buff[ldump.DIBS - 1] | 0x80;
        const result = buff.slice(ldump.DIBS - n, ldump.DIBS);
        let str = "";
        for (const byte of result) {
            str += String.fromCharCode(byte);
        }
        this.dumpVector(str, n);
    }

    dumpVector(s, n) {
        this.buffer.push(s.slice(0, n));
    }

    dumpString(s) {
        if (s === null) {
            this.dumpSize(0);
        } else {
            const size = s.length;
            this.dumpSize(size + 1);
            this.dumpVector(s, size);
        }
    }

    dumpFunction(f, psource) {
        if (this.strip || f.source === psource) {
            this.dumpString(null);
        } else {
            this.dumpString(f.source);
        }
        this.dumpInt(f.linedefined);
        this.dumpInt(f.lastlinedefined);
        this.dumpByte(f.numparams);
        this.dumpByte(f.is_vararg);
        this.dumpByte(f.maxstacksize);
        this.dumpCode(f);
        this.dumpConstants(f);
        this.dumpUpvalues(f);
        this.dumpProtos(f);
        this.dumpDebug(f);
    }

    dumpDebug(f) {
        let n = this.strip ? 0 : f.sizelineinfo;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpByte(f.lineinfo[i]);
        }

        n = this.strip ? 0 : f.sizeabslineinfo;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpInt(f.abslineinfo[i].pc);
            this.dumpInt(f.abslineinfo[i].line);
        }

        n = this.strip ? 0 : f.sizelocvars;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpString(f.locvars[i].varname);
            this.dumpInt(f.locvars[i].startpc);
            this.dumpInt(f.locvars[i].endpc);
        }

        n = this.strip ? 0 : f.sizeupvalues;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpString(f.upvalues[i].name);
        }
    }

    dumpProtos(f) {
        const n = f.sizep;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpFunction(f.p[i], f.source);
        }
    }

    dumpUpvalues(f) {
        const n = f.sizeupvalues;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            this.dumpByte(f.upvalues[i].instack);
            this.dumpByte(f.upvalues[i].idx);
            this.dumpByte(f.upvalues[i].kind);
        }
    }

    dumpConstants(f) {
        const n = f.sizek;
        this.dumpInt(n);
        for (let i = 0; i < n; i++) {
            const o = f.k[i];
            const tt = ttypetag(o);
            this.dumpByte(tt);
            if (tt === LUA_VNUMFLT) {
                this.dumpNumber(o.get());
            } else if (tt === LUA_VNUMINT) {
                this.dumpInteger(o.get());
            } else if (tt === LUA_VSHRSTR || tt === LUA_VLNGSTR) {
                this.dumpString(o.get());
            }
        }
    }

    dumpCode(f) {
        this.dumpInt(f.sizecode);
        const isLittleEndian = lundump.LUAC_FORMAT === 0;
        for (let i = 0; i < f.sizecode; i++) {
            const inst = f.code[i];
            const buffer = new ArrayBuffer(4);
            const view = new DataView(buffer);
            view.setInt32(0, inst.instruction, isLittleEndian);
            const bytes = new Uint8Array(buffer);
            let str = "";
            for (const byte of bytes) {
                str += String.fromCharCode(byte);
            }
            this.buffer.push(str);
        }
    }

    dumpInt(x) { this.dumpSize(x); }

    dumpHeader() {
        this.dumpLiteral(lundump.LUA_SIGNATURE);
        this.dumpByte(lundump.LUAC_VERSION);
        this.dumpByte(lundump.LUAC_FORMAT);
        this.dumpLiteral(lundump.LUAC_DATA);
        this.dumpByte(lundump.sizeof_Instruction);
        this.dumpByte(lundump.sizeof_lua_Integer);
        this.dumpByte(lundump.sizeof_lua_Number);
        this.dumpInteger(lundump.LUAC_INT);
        this.dumpNumber(lundump.LUAC_NUM);
    }

    dumpLiteral(str) {
        this.buffer.push(str);
    }

    dumpByte(b) {
        if (typeof b === "boolean") {
            b = b ? 1 : 0;
        }
        this.buffer.push(b ? "\x01" : "\x00");
    }

    dumpInteger(b) {
        const isLittleEndian = lundump.LUAC_FORMAT === 0;
        const buffer = new ArrayBuffer(8);
        const view = new DataView(buffer);
        view.setBigInt64(0, BigInt(b), isLittleEndian);
        const bytes = new Uint8Array(buffer);
        let str = "";
        for (const byte of bytes) {
            str += String.fromCharCode(byte);
        }
        this.buffer.push(str);
    }

    dumpNumber(b) {
        const isLittleEndian = lundump.LUAC_FORMAT === 0;
        const buffer = new ArrayBuffer(8);
        const view = new DataView(buffer);
        view.setFloat64(0, b, isLittleEndian);
        const bytes = new Uint8Array(buffer);
        let str = "";
        for (const byte of bytes) {
            str += String.fromCharCode(byte);
        }
        this.buffer.push(str);
    }
}

export {
    ldump,
    lundump,
    Instruction,
    iABC,
    iABx,
    iAsBx,
    iAx,
    isJ,
    Upvaldesc,
    LocVar,
    AbsLineInfo,
    TValue,
    Proto,
};