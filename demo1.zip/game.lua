--// 游戏主类 - 控制游戏流程和状态
class MemoryGame {
    boardElement;
    movesElement;
    matchesElement;
    timeElement;
    cards = {};
    selectedCards = {};
    @nowrap moves = 0;
    @nowrap matches = 0;
    @nowrap time = 0;
    timer;
    @nowrap gameStarted = false;

    MemoryGame(boardElement, movesElement, matchesElement, timeElement) {
        self.boardElement = boardElement;
        self.movesElement = movesElement;
        self.matchesElement = matchesElement;
        self.timeElement = timeElement;
        self.init();
    }
    
    init() {
        --// 创建卡片对
        local symbols = {'🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼'};
        local cardValues = {};
        for key, value in pairs(symbols) do
            table.insert(cardValues, value);
            table.insert(cardValues, value);
        end
        --// 洗牌
        self.shuffleArray(cardValues);
        --// 创建卡片对象
        for key, value in pairs(cardValues) do
            table.insert(self.cards,  Card(value, key, self));
        end
        --// 渲染卡片
        self.render();
        --// 重置游戏状态
        self.resetGameState();
    }
    
    render() {
        self.boardElement.innerHTML = '';
        for index, card in pairs(self.cards) do
            self.boardElement.appendChild(card.element);
        end
    }
    
    shuffleArray(array) {
        for i = #array, 1, -1 do
            local j = math.random(#array);
            array[i], array[j] = array[j], array[i];
        end
    }
    
    resetGameState() {
        self.selectedCards = {};
        self.moves = 0;
        self.matches = 0;
        self.time = 0;
        self.gameStarted = false;
        self.updateUI();
        self.stopTimer();
        --// 重置所有卡片状态
        for key, card in pairs(self.cards) do
            card.reset();
        end
    }
    
    startTimer() {
        self.gameStarted = true;
        self.timer = setInterval(function ()
            self.time = self.time + 1;
            self.timeElement.textContent = self.time;
        end, 1000);
    }
    
    stopTimer() {
        if (self.timer) then
            clearInterval(self.timer);
            self.timer = nil
        end
    }
    
    handleCardClick(card) {
        --// 如果游戏未开始，开始计时
        if (not self.gameStarted) then
            self.startTimer();
        end
        --// 如果卡片已匹配或已选中，忽略点击
        -- if (card.matched or self.selectedCards.includes(card)) then
        --     return;
        -- end
        if (card.matched) then
            return;
        end
        for k,v in pairs(self.selectedCards) do
            if (v == card) then
                return;
            end
        end
        --// 如果已经有两张卡片选中，忽略点击
        if (#self.selectedCards >= 2) then
           return;
        end
        --// 翻转卡片
        card.flip();
        --// 添加到选中卡片
        table.insert(self.selectedCards, card);
        --// 如果选中了两张卡片，检查是否匹配
        if (#self.selectedCards == 2) then
            self.moves = self.moves + 1;
            self.updateUI();
            if (self.selectedCards[1].value == self.selectedCards[2].value) then
                --// 匹配成功
                self.handleMatch();
            else
                --// 不匹配，稍后翻转回来
                setTimeout(function ()
                    for key, card in pairs(self.selectedCards) do
                        card.flip();
                    end
                    self.selectedCards = {};
                end, 1000);
            end
        end
    }
    
    handleMatch() {
        for key, card in pairs(self.selectedCards) do
            card.setMatched();
        end
        self.matches = self.matches + 1;
        self.selectedCards = {};
        self.updateUI();
        --// 检查游戏是否结束
        if (self.matches == #self.cards / 2) then
            self.stopTimer();
            setTimeout(function ()
                local message = "恭喜！你赢了！\n回合数: " .. self.moves .. "\n用时: " .. self.time .. "秒";
                alert(message);
            end, 500);
        end
    }
    
    updateUI() {
        self.movesElement.textContent = self.moves;
        self.matchesElement.textContent = self.matches;
    }
    
    resetGame() {
        self.stopTimer();
        self.shuffleArray(self.cards);
        self.resetGameState();
        self.render();
    }
}

--// 卡片类 - 表示单个卡片
class Card {
    value;
    id;
    game;
    @nowrap matched = false;
    @nowrap flipped = false;
    element;
    frontElement;
    backElement;
    Card(value, id, game) {
        self.value = value;
        self.id = id;
        self.game = game;
        self.element = document.createElement('div');
        self.element.className = 'card';
        self.element.dataset.id = self.id;
        --// 创建卡片正反面
        self.frontElement = document.createElement('div');
        self.frontElement.className = 'card-face card-front';
        self.frontElement.textContent = '?';
        self.backElement = document.createElement('div');
        self.backElement.className = 'card-face card-back';
        self.backElement.textContent = self.value;
        self.element.appendChild(self.frontElement);
        self.element.appendChild(self.backElement);
        --// 添加点击事件
        self.element.addEventListener('click',function()
            self.game.handleCardClick(self);
        end);
    }
    
    flip() {
        self.flipped = not self.flipped;
        if (self.flipped) then
            self.element.classList.add('flipped');
        else
            self.element.classList.remove('flipped');
        end
    }
    
    setMatched() {
        self.matched = true;
        self.element.classList.add('matched');
        self.element.style.cursor = 'default';
    }
    
    reset() {
        self.matched = false;
        self.flipped = false;
        self.element.classList.remove('flipped', 'matched');
        self.element.style.cursor = 'pointer';
    }
}
local gameBoard = document.getElementById('gameBoard');
local movesElement = document.getElementById('moves');
local matchesElement = document.getElementById('matches');
local timeElement = document.getElementById('time');
local resetBtn = document.getElementById('resetBtn');

--// 创建游戏实例
local game = MemoryGame(
    gameBoard, 
    movesElement, 
    matchesElement, 
    timeElement
);

--// 重置按钮事件
resetBtn.addEventListener('click',function()
    game.resetGame();
end);